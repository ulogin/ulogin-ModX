<?php
require_once (dirname(dirname(__FILE__)) . '/uloginwidget.class.php');
class uLoginWidget_mysql extends uLoginWidget {}