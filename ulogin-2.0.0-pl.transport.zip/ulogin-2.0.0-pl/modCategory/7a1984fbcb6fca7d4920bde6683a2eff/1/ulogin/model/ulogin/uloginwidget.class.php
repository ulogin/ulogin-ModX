<?php
class uLoginWidget extends xPDOSimpleObject {}