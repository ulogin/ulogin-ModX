<?php
$xpdo_meta_map['uLoginWidget']= array (
  'package' => 'ulogin',
  'version' => '1.0',
  'table' => 'ulogin_widget',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'uloginid' => '',
  ),
  'fieldMeta' => 
  array (
    'uloginid' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '100',
      'phptype' => 'string',
      'default' => '',
    ),
  ),
);
