<?php
$_lang['ulogin_prop.id_desc'] = 'Идентификатор html элемента, использующийся для виджета';
$_lang['ulogin_prop.displ_desc'] = 'Вариант отображения виджета (small/panel/window)';
$_lang['ulogin_prop.wintip_desc'] = 'Всплывающая подсказка над виджетом в виде окна';
$_lang['ulogin_prop.fields_desc'] = 'Список запрашиваемых полей из профиля пользователя';
$_lang['ulogin_prop.prov_desc'] = 'Список отображаемых провайдеров на панели виджета';
$_lang['ulogin_prop.hidden_desc'] = 'Список провайдеров в выпадающем меню виджета';
$_lang['ulogin_prop.redirect_desc'] = 'Ссылка для получения токена';
$_lang['ulogin_prop.call_desc'] = 'Java script функция для получения токена без редиректа';
$_lang['ulogin_prop.usrhello_desc'] = 'Приветствие пользователя в шаблоне userpanel';
$_lang['ulogin_prop.usrprofile_desc'] = 'Ссылка на профиль пользователя';
$_lang['ulogin_prop.signoutmsg_desc'] = 'Название ссылки на выход из профиля в шаблоне userpanel';
$_lang['ulogin_prop.signouturl_desc'] = 'Cсылка на выход из профиля в шаблоне userpanel';
$_lang['ulogin_prop.usrpanel_desc'] = 'Название шаблона пользовательской панели(по умолчанию userpanel). Файл в формате "*.chunk.tpl"';
?>
