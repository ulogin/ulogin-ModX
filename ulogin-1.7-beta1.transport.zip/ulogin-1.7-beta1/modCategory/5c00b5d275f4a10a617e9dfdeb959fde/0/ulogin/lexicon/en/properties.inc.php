<?php
$_lang['ulogin_prop.id_desc'] = 'Widget\'s id';
$_lang['ulogin_prop.displ_desc'] = 'Display option (small/panel/window)';
$_lang['ulogin_prop.wintip_desc'] = 'Tip';
$_lang['ulogin_prop.fields_desc'] = 'The list of requested fields from the user profile';
$_lang['ulogin_prop.prov_desc'] = 'List of providers on panel';
$_lang['ulogin_prop.hidden_desc'] = 'List of providers on dropdown menu';
$_lang['ulogin_prop.redirect_desc'] = 'Link to receive token';
$_lang['ulogin_prop.call_desc'] = 'Java script function to receive token without redirect';
$_lang['ulogin_prop.usrhello_desc'] = 'User\'s greeting';
$_lang['ulogin_prop.usrprofile_desc'] = 'Link to user profile';
$_lang['ulogin_prop.signoutmsg_desc'] = 'Description for "Sign out" link';
$_lang['ulogin_prop.signouturl_desc'] = '"Sign out" link';
$_lang['ulogin_prop.usrpanel_desc'] = 'Name of user panel\'s template (default - userpanel). File wildcard "*.chunk.tpl"';
?>
