<?php
require_once (dirname(dirname(__FILE__)) . '/uloginuser.class.php');
class uLoginUser_mysql extends uLoginUser {}