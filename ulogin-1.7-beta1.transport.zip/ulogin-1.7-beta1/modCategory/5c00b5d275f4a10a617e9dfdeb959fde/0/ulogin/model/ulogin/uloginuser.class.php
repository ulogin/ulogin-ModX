<?php
class uLoginUser extends xPDOSimpleObject {}